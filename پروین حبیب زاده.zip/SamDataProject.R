
# بارگذاری داده ها
data <- read.csv("E:/University/6استاد محسن مهدی نیا-تحلیل آماری در آر/پروژه نهایی/Project/Samdata.csv", header = TRUE, sep = ",", stringsAsFactors = FALSE)

#بررسی اولیه داده ها
head(data)
names(data)
str(data)
summary(data)

# تغییر نام ستون Repaire_Action_Desc به Action
colnames(data)[colnames(data) == "Repaire_Action_Desc"] <- "Action"
names(data)
"Action" %in% names(data)

# تعداد مقادیر گمشده در ستون Product_Date
sum(is.na(data$Product_Date))
mean(is.na(data$Product_Date))
if (mean(is.na(data$Product_Date)) > 0.5) {
  data$Product_Date <- NULL
}

total_rows <- nrow(data)
missing_count <- sum(is.na(data$Product_Date))
missing_percentage <- (missing_count / total_rows) * 100
missing_percentage
if (missing_percentage > 50) {
  data$Product_Date <- NULL
}
names(data)

# محاسبه میانگین سرعت خدمات
mean_TAT01 <- mean(data$TAT01, na.rm = TRUE)
mean_TAT02 <- mean(data$TAT02, na.rm = TRUE)
mean_TAT01
mean_TAT02
missing_TAT01 <- sum(is.na(data$TAT01)) / length(data$TAT01) * 100
missing_TAT02 <- sum(is.na(data$TAT02)) / length(data$TAT02) * 100
missing_TAT01
missing_TAT02

# نمایش تعداد داده های تکراری
duplicate_products <- data[duplicated(data$Serial_No) | duplicated(data$Serial_No, fromLast = TRUE), ]
num_duplicates <- nrow(duplicate_products)
total_products <- nrow(data)
return_rate <- (num_duplicates / total_products) * 100
num_duplicates
return_rate

# رسم نمودار ستونی برای وضعیت گارانتی (Cost_Type)
install.packages("ggplot2")
library(ggplot2)
ggplot(data, aes(x = Cost_Type)) +
  geom_bar(fill = "skyblue", color = "black") +
  labs(title = "توزیع وضعیت گارانتی", x = "وضعیت گارانتی", y = "تعداد") +
  theme_minimal()

# بررسی نوع داده ها
str(data)
numeric_columns <- sapply(data, is.numeric)
numeric_data <- data[, numeric_columns]

# ایجاد مدل رگرسیون خطی
model <- lm(Total_Invoice_Amount ~ ., data = numeric_data)
summary(model)
model_summary <- summary(model)
model_summary$r.squared

# نصب بسته arules
install.packages("arules")

# اجرای الگوریتم Apriori با تنظیمات پیشرفته تر
rules <- apriori(
  trans_data, 
  parameter = list(
    support = 0.01,
    confidence = 0.7,
    minlen = 2, 
    maxlen = 5, 
    target = "rules"
  )
)
length(rules)
inspect(head(rules, 10))
filtered_rules <- subset(rules, lift > 1)
inspect(head(filtered_rules, 10))

colnames(data)
# انتخاب ویژگی‌های عددی برای خوشه‌بندی
data_numeric <- data[, c("Total_Invoice_Amount", "TAT01", "TAT02")]
data_scaled <- scale(data_numeric)
set.seed(123)
kmeans_result <- kmeans(data_scaled, centers = 3, nstart = 25)
kmeans_result$cluster
kmeans_result$centers
kmeans_result$tot.withinss
# نمایش نتایج روی نمودار
library(ggplot2)
data_with_cluster <- cbind(data_numeric, Cluster = as.factor(kmeans_result$cluster))
ggplot(data_with_cluster, aes(x = TAT01, y = TAT02, color = Cluster)) +
  geom_point() +
  labs(title = "K-Means Clustering", x = "TAT01", y = "TAT02")

library(arules)

# تبدیل داده‌ها به مجموعه‌های تراکنش (Transaction)
# برای مثال، از ستون‌های "Cost_Type" و "Product_Group" به عنوان ویژگی‌های اولیه استفاده می‌کنیم
data_transactions <- as(data[, c("Cost_Type", "Product_Group")], "transactions")

# اجرای الگوریتم Apriori برای کشف قوانین انجمنی
rules <- apriori(data_transactions, parameter = list(support = 0.1, confidence = 0.8, minlen = 2))

# بررسی قوانین کشف شده
inspect(rules)

# نمایش تمامی قوانین کشف شده
inspect(sort(rules, by = "confidence"))



